/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package b7;

/**
 *
 * @author ADMIN
 */
class Subject implements Comparable<Subject> {

    public String id, name, exam;

    public Subject(String id, String name, String exam) {
        this.id = id;
        this.name = name;
        this.exam = exam;
    }

    @Override
    public int compareTo(Subject o) {
        return id.compareTo(o.id);
    }

    @Override
    public String toString() {
        return id + " " + name + " " + exam;
    }
}

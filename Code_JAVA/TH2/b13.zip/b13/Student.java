class Student {
    public String ID, name, phoneNumber, email;

    public Student(String ID, String name, String phoneNumber, String email) {
        this.ID = ID;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }
}
